title: 自定义react、typescript开发脚手架
date: '2019-09-04 11:52:16'
updated: '2019-09-04 12:10:23'
tags: [webpack, typescript]
permalink: /articles/2019/09/04/1567569136582.html
---
![](https://img.hacpai.com/bing/20180427.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

为什么会写这篇文章呢，主要想记录下自己遇到的问题，以供后续查找。

一、前期准备

  react全家桶，typescript、webpack

1.1 初始化工程
```
mkdir webpack-react-project && cd webpack-react-project && npm init -y
```

1.2 安装依赖
```
npm i -D react react-dom react-router-dom webpack webpack-cli typescript @type/react @type/react-dom @type/react-router-dom
```
暂时先安装这么多，后面需要用那个了再安装.

1.3 目录结构
```
// webpack-react-project

.
├── Dockerfile   				// docker  配置文件，自动化部署
├── README.md			// readme
├── config					// --config
│   ├── webpack.base.js		//  webpack base config
│   ├── webpack.config.js	// 
│   ├── webpack.dev.js		// dev
│   └── webpack.prod.js		// pord
├── dist					// 输出文件目录
│   └── bundle.js	
├── package-lock.json		
├── package.json
├── src					// 源码文件
│   ├── App.tsx
│   ├── Layout
│   │   └── Layout.tsx
│   ├── assets
│   │   └── index.html
│   ├── components			// 组件
│   │   └── header
│   │       ├── index.css
│   │       ├── index.css.map
│   │       ├── index.sass
│   │       └── index.tsx
│   ├── index.css
│   ├── index.css.map
│   ├── index.sass
│   ├── index.tsx			// 入口点
│   ├── router.js
│   └── styles
│       └── global.sass		// 全局样式
└── tsconfig.json			// typescript 配置
```
1.4 创建webpack配置文件
```
'use strict'

const path = require('path')
const resolve = dir => path.resolve(__dirname, dir)

module.exports = {
  mode: 'development',
  entry: resolve('../src/index.tsx'),
  devtool: 'inline-source-map',
  output: {
    filename: "bundle.js",
    path: resolve('../dist')
  },
  resolve: {
    extensions: [ '.ts', '.tsx', '.js', '.json' ],
  },
  module: {
    rules: [
      { test: /\.tsx$/, use: 'ts-loader', exclude: /node_modules/ }
    ],
  },
  externals: {
    "react": "React",
    "react-dom": "RactDOM"
  }
}
```
这里的代码不懂可以去看[webpack]([https://www.webpackjs.com](https://www.webpackjs.com/))官网.

1.5 创建文件


