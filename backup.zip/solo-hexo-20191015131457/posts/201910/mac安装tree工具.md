title: mac安装tree工具
date: '2019-10-14 17:40:33'
updated: '2019-10-14 17:40:33'
tags: [mac, 实用工具]
permalink: /articles/2019/10/14/1571046032883.html
---
![](https://img.hacpai.com/bing/20181227.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

mac安装tree工具，方便在项目下生成tree树

#### 安装

```
// bash
brew install tree
```

在自己的项目下使用

如下:
```
.
├── README.md
├── app
│   ├── auth
│   │   └── role.js
│   ├── controller
│   │   ├── home.js
│   │   └── users.js
│   ├── domain
│   │   ├── user.js
│   │   └── userLogin.js
│   ├── middleware
│   │   ├── error_handler.js
│   │   ├── gizp_handler.js
│   │   └── jwt_session.js
│   ├── model
│   │   ├── user.js
│   │   └── userLogin.js
│   ├── public
│   ├── router
│   │   ├── router.local.js
│   │   └── router.prod.js
│   ├── router.js
│   ├── service
│   │   └── users.js
│   └── utils
│       └── util.js
├── app.js
├── appveyor.yml
├── config
│   ├── config.default.js
│   ├── config.local.js
│   ├── config.prod.js
│   └── plugin.js
├── data
│   ├── create_db_v1.0.sql
│   └── inster_db_init.sql
├── jsconfig.json
├── logs
│   └── ashop_service
│       ├── ashop_service-web.log
│       ├── common-error.log
│       ├── egg-agent.log
│       ├── egg-schedule.log
│       └── egg-web.log
├── package-lock.json
├── package.json
├── run
│   ├── agent_config.json
│   ├── agent_config_meta.json
│   ├── agent_timing_43008.json
│   ├── application_config.json
│   ├── application_config_meta.json
│   ├── application_timing_43010.json
│   ├── application_timing_92330.json
│   └── router.json
├── test
│   └── app
│       └── controller
│           └── home.test.js
└── typings
    ├── app
    │   ├── controller
    │   │   └── index.d.ts
    │   ├── index.d.ts
    │   ├── middleware
    │   │   └── index.d.ts
    │   ├── model
    │   │   └── index.d.ts
    │   └── service
    │       └── index.d.ts
    └── config
        ├── index.d.ts
        └── plugin.d.ts
```

OK!至此小工具安装完毕！
