title: 从Vue源码分析Vue执行过程
date: '2019-10-14 19:52:10'
updated: '2019-10-14 20:59:34'
tags: [Vue]
permalink: /articles/2019/10/14/1571053930668.html
---
![](https://img.hacpai.com/bing/20180212.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


初入茅庐，开始我们的vue之旅！

刚开始看源码，不要一行一行看，建议新建一 `demo` debug慢慢调试，一点一点读，这里采用配合项目的形式，加深我们在项目中对具体方法的认知！

打开vue源码项目你会发现有这么几个目录，如下：
```
# bash
.
├── dist			// dist		
├── src				// 源码目录
│   ├── compiler		// 编译相关
│   │   ├── codegen
│   │   ├── directives
│   │   └── parser
│   ├── core			// 核心
│   │   ├── components
│   │   ├── global-api
│   │   ├── instance
│   │   │   └── render-helpers
│   │   ├── observer
│   │   ├── util
│   │   └── vdom
│   │       ├── helpers
│   │       └── modules
│   ├── platforms		// 平台相关
│   │   ├── web
│   │   │   ├── compiler
│   │   │   │   ├── directives
│   │   │   │   └── modules
│   │   │   ├── runtime
│   │   │   │   ├── components
│   │   │   │   ├── directives
│   │   │   │   └── modules
│   │   │   ├── server
│   │   │   │   ├── directives
│   │   │   │   └── modules
│   │   │   └── util
│   │   └── weex
│   │       ├── compiler
│   │       │   ├── directives
│   │       │   └── modules
│   │       │       └── recycle-list
│   │       ├── runtime
│   │       │   ├── components
│   │       │   ├── directives
│   │       │   ├── modules
│   │       │   └── recycle-list
│   │       └── util
│   ├── server			// 服务端渲染
│   │   ├── bundle-renderer
│   │   ├── optimizing-compiler
│   │   ├── template-renderer
│   │   └── webpack-plugin
│   ├── sfc
│   └── shared		// .vue 解析文件
└── types			// 测试 

```
compiler: 主要用于编译
core: 这里是核心中的核心，主要是vnode、核心api、等一些重要的封装
platforms: 适配多端平台， 比如 native（vexx）、web
server: 服务端渲染
sfc: 这里主要是webpack对vue代码编译相关
shared: 对 .vue 文件的解析

一、入口文件加载

在我们配置好项目后，debugger，点击进入：
![11.png](https://img.hacpai.com/file/2019/10/11-5ea6ca52.png)
进入断点：
![22.png](https://img.hacpai.com/file/2019/10/22-e26b0e46.png)
会看到这样两段代码，这里定义了一个Vue实例，也就是new Vue的出处，
这里执行了 `this._init(options)`，进而我们看看这个方法做了那些事，
这里直接贴上源码，方便阅读理解：
```
// 混入方法，接收Vue实例<Component>
export function initMixin (Vue: Class<Component>) {
  Vue.prototype._init = function (options?: Object) {
    const vm: Component = this
    // a uid
    // 唯一递增的id
    vm._uid = uid++

    let startTag, endTag
    /* istanbul ignore if */
    if (process.env.NODE_ENV !== 'production' && config.performance && mark) {
      startTag = `vue-perf-start:${vm._uid}`
      endTag = `vue-perf-end:${vm._uid}`
      mark(startTag)
    }

    // a flag to avoid this being observed
    // 如果是vue实例，则不需要被observe
    vm._isVue = true
    // merge options
    // 第一步： 对options参数进行处理
    if (options && options._isComponent) {
      // optimize internal component instantiation
      // since dynamic options merging is pretty slow, and none of the
      // internal component options needs special treatment.
      initInternalComponent(vm, options)
    } else {
      vm.$options = mergeOptions(
        resolveConstructorOptions(vm.constructor),
        options || {},
        vm
      )
    }
    /* istanbul ignore else */
    // 第二步 renderProxy
    if (process.env.NODE_ENV !== 'production') {
      initProxy(vm)
    } else {
      vm._renderProxy = vm
    }
    // expose real self
    vm._self = vm
    // 第三步 vm生命周期钩子
    initLifecycle(vm)// 做了一些生命周期的初始化工作，初始化了很多变量，最主要是设置了父子组件的引用关系，也就是设置了 `$parent` 和 `$children`的值
    
    // 第四步 vm 事件初始化监听
    initEvents(vm)// 注册事件，注意这里注册的不是自己的，而是父组件的。因为很明显父组件的监听器才会注册到孩子身上。
    initRender(vm)// 做一些 render 的准备工作，比如处理父子继承关系等，并没有真的开始 render
    callHook(vm, 'beforeCreate')// 准备工作完成，接下来进入 `create` 阶段
    initInjections(vm) // resolve injections before data/props
    
    // 第五步 vm状态初始化
    initState(vm)// `data`, `props`, `computed` 等都是在这里初始化的，常见的面试考点比如`Vue是如何实现数据响应化的` 答案就在这个函数中寻找
    initProvide(vm) // resolve provide after data/props
    callHook(vm, 'created')

    /* istanbul ignore if */
    if (process.env.NODE_ENV !== 'production' && config.performance && mark) {
      vm._name = formatComponentName(vm, false)
      mark(endTag)
      measure(`vue ${vm._name} init`, startTag, endTag)
    }

    // 第六步 render 挂在到 $mount
    if (vm.$options.el) {
      vm.$mount(vm.$options.el) // el $mount
    }
  }
}
```
debugger过程图示：
![33.png](https://img.hacpai.com/file/2019/10/33-d3fca7e3.png)

#### options:

首先vue会先对options参数进行处理，这里主要是合并options参数，具体下面讲.

#### renderProxy:
 这里使用Proxy代理，把 `render` 中的this指向 `renderProxy`,也就是vm实例。

#### initLifecycle: 
这里做了一些生命周期的初始化工作，初始化了很多变量，最主要是设置了父子组件的引用关系，也就是设置了 `$parent` 和 `$children`的值。
![44.png](https://img.hacpai.com/file/2019/10/44-3bcc2889.png)



#### initEvents:
注册事件，注意这里注册的不是自己的，而是父组件的。因为父组件的监听器才会注册到子组件身上。
![55.png](https://img.hacpai.com/file/2019/10/55-f65969cf.png)
源码：
```
//instance/events.js
/*
 * @Description: In User Settings Edit
 * @Author: your name
 * @Date: 2019-08-14 10:42:22
 * @LastEditTime: 2019-08-15 16:41:19
 * @LastEditors: Please set LastEditors
 */
/* @flow */

import {
  tip,
  toArray,
  hyphenate,
  formatComponentName,
  invokeWithErrorHandling
} from '../util/index'
import { updateListeners } from '../vdom/helpers/index'

// 初始化event事件
export function initEvents (vm: Component) {
  // 创建一个新对象，并复制给vm._events实例
  vm._events = Object.create(null)
  // bool钩子用于标志位作用，这里没用哈希表查找是否有钩子，可以减少开销、性能优化
  vm._hasHookEvent = false
  // init parent attached events
  // 初始化父组件attached的事件
  const listeners = vm.$options._parentListeners
  if (listeners) {
    updateComponentListeners(vm, listeners)
  }
}

let target: any

function add (event, fn) {
  target.$on(event, fn)
}

function remove (event, fn) {
  target.$off(event, fn)
}

function createOnceHandler (event, fn) {
  const _target = target
  return function onceHandler () {
    const res = fn.apply(null, arguments)
    if (res !== null) {
      _target.$off(event, onceHandler)
    }
  }
}

export function updateComponentListeners (
  vm: Component,
  listeners: Object,
  oldListeners: ?Object
) {
  target = vm
  updateListeners(listeners, oldListeners || {}, add, remove, createOnceHandler, vm)
  target = undefined
}

export function eventsMixin (Vue: Class<Component>) {
  const hookRE = /^hook:/
  /**
   * 绑定一个自定义监听事件
   * @event {String|Array<string>} event
   * @fn {function} function
   * @returns Component
   */
  Vue.prototype.$on = function (event: string | Array<string>, fn: Function): Component {
    const vm: Component = this
    // 如果是数组，则递归为每个绑定$on
    if (Array.isArray(event)) {
      for (let i = 0, l = event.length; i < l; i++) {
        vm.$on(event[i], fn)
      }
    } else {
      (vm._events[event] || (vm._events[event] = [])).push(fn)
      // optimize hook:event cost by using a boolean flag marked at registration
      // instead of a hash lookup
      // 改变标识位，这里用bool是为了性能优化
      if (hookRE.test(event)) {
        vm._hasHookEvent = true
      }
    }
    return vm
  }

  /**
   * 监听一个只能监听一次的事件，用完直接被销毁
   * @event {String} 事件
   * @fn {function} fn 回调函数
   * @returns Component
   */
  Vue.prototype.$once = function (event: string, fn: Function): Component {
    const vm: Component = this
    function on () {
      // 在第一执行后直接移除
      vm.$off(event, on)
      // 执行注册方法
      fn.apply(vm, arguments)
    }
    on.fn = fn
    vm.$on(event, on)
    return vm
  }

  /**
   * 销毁事件
   * @event {String|Array<string>} event
   * @fn {function} function 
   * @returns Component
   */
  Vue.prototype.$off = function (event?: string | Array<string>, fn?: Function): Component {
    const vm: Component = this
    // all
    // 如果不传参直接删除所有事件
    if (!arguments.length) {
      vm._events = Object.create(null)
      return vm
    }
    // array of events
    // 如果传入参数是数组，则递归删除
    if (Array.isArray(event)) {
      for (let i = 0, l = event.length; i < l; i++) {
        vm.$off(event[i], fn)
      }
      return vm
    }
    // specific event
    const cbs = vm._events[event]
    // 本身不存在直接返回
    if (!cbs) {
      return vm
    }
    if (!fn) {
      vm._events[event] = null
      return vm
    }
    // specific handler
    // 遍历寻找对应方法并删除
    let cb
    let i = cbs.length
    while (i--) {
      cb = cbs[i]
      if (cb === fn || cb.fn === fn) {
        cbs.splice(i, 1)
        break
      }
    }
    return vm
  }

  /**
   * 触发当前实例上的事件。附加参数都会传给监听器回调
   * @event {String} event
   * @returns Component
   */
  Vue.prototype.$emit = function (event: string): Component {
    const vm: Component = this
    // 如果是生产环境 dev
    if (process.env.NODE_ENV !== 'production') {
      const lowerCaseEvent = event.toLowerCase()
      if (lowerCaseEvent !== event && vm._events[lowerCaseEvent]) {
        tip(
          `Event "${lowerCaseEvent}" is emitted in component ` +
          `${formatComponentName(vm)} but the handler is registered for "${event}". ` +
          `Note that HTML attributes are case-insensitive and you cannot use ` +
          `v-on to listen to camelCase events when using in-DOM templates. ` +
          `You should probably use "${hyphenate(event)}" instead of "${event}".`
        )
      }
    }
    let cbs = vm._events[event]
    if (cbs) {
      // 将类数组转成数组
      cbs = cbs.length > 1 ? toArray(cbs) : cbs
      const args = toArray(arguments, 1)
      const info = `event handler for "${event}"`
      // 遍历执行
      for (let i = 0, l = cbs.length; i < l; i++) {
        invokeWithErrorHandling(cbs[i], vm, args, vm, info)
      }
    }
    return vm
  }
}

```

#### initRender:
做一些 render 的准备工作，比如处理父子继承关系等，并没有真的开始 render。
![66.png](https://img.hacpai.com/file/2019/10/66-712ac42e.png)


#### calHook:
 准备工作完成，接下来进入 `create` 阶段。


#### initInjections:
初始化 data、props数据

#### initState:
初始化 data、props、computed、等

#### initProvider:
加载provider

最后就是将render挂在到$mount上
```
// 挂在$mount
if (vm.$options.el) {
      vm.$mount(vm.$options.el)// el $mount
    }
```
接下来解释每个的主要功能！




