title: javascript 的节流与防抖
date: '2019-09-03 22:07:42'
updated: '2019-09-03 22:07:42'
tags: [javascript]
permalink: /articles/2019/09/03/1567519662462.html
---
防抖：
```
function debounc(fn,wait,immdiate) {
	let timer = null;
	
	return function() {
		let ars = arguments;
		let context = this;
		
		if (immdiate && !timer) {
			fn.apply(context, args);
		} 

		if (timer) clearTimeout(timer);
		timer = setTimeout => (() => {
			fn.apply(context, args);
		}, wait)
	}
}
```

节流：

```
function throttle(fn, wait, immediate) {
	let timer = null;
	let callNow = immediate;

	return function () {
		let context = this,
		args = arguments;

		if (callNow) {
			fn.apply(context, args);
			callNow = false;
		}

		if (!timer) {
			timer = setTimeout(() => {
				fn.apply(context, args);
				timer = null;
			}, wait);
		}
	}
};
```
