title: eggjs搭建RefulAPI（一）
date: '2019-10-14 17:07:01'
updated: '2019-10-14 17:32:28'
tags: [eggjs]
permalink: /articles/2019/10/14/1571044021347.html
---
![](https://img.hacpai.com/bing/20171114.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

#### 记录下使用egg搭配sequlize+mysql搭建RefulAPI，配置篇

#### 安装 `eggjs`

初始化项目
```shell
mkdir egg-example && cd egg-example
npm init egg --type=simple
npm i
```
具体可以参考 `eggjs` [官网](https://eggjs.org/).

安装完成目录结构如下：
```
.
├── README.md
├── app
│   ├── auth
│   │   └── role.js
│   ├── controller
│   │   ├── home.js
│   │   └── users.js
│   ├── domain
│   │   ├── user.js
│   │   └── userLogin.js
│   ├── middleware
│   │   ├── error_handler.js
│   │   ├── gizp_handler.js
│   │   └── jwt_session.js
│   ├── model
│   │   ├── user.js
│   │   └── userLogin.js
│   ├── public
│   ├── router
│   │   ├── router.local.js
│   │   └── router.prod.js
│   ├── router.js
│   ├── service
│   │   └── users.js
│   └── utils
│       └── util.js
├── app.js
├── appveyor.yml
├── config
│   ├── config.default.js
│   ├── config.local.js
│   ├── config.prod.js
│   └── plugin.js
├── data
│   ├── create_db_v1.0.sql
│   └── inster_db_init.sql
├── jsconfig.json
├── logs
│   └── ashop_service
│       ├── ashop_service-web.log
│       ├── common-error.log
│       ├── egg-agent.log
│       ├── egg-schedule.log
│       └── egg-web.log
├── package-lock.json
├── package.json
├── run
│   ├── agent_config.json
│   ├── agent_config_meta.json
│   ├── agent_timing_43008.json
│   ├── application_config.json
│   ├── application_config_meta.json
│   ├── application_timing_43010.json
│   ├── application_timing_92330.json
│   └── router.json
├── test
│   └── app
│       └── controller
│           └── home.test.js
└── typings
    ├── app
    │   ├── controller
    │   │   └── index.d.ts
    │   ├── index.d.ts
    │   ├── middleware
    │   │   └── index.d.ts
    │   ├── model
    │   │   └── index.d.ts
    │   └── service
    │       └── index.d.ts
    └── config
        ├── index.d.ts
        └── plugin.d.ts
```


#### **安装**
```
npm install sequlize -S
```
#### **配置**
```
// plugin.js
exports.sequelize = {
  enable: true,
  package: 'egg-sequelize'
}
```
```
// config.default.js
 // sequelize config
  config.sequelize = {
    dialect: 'mysql', // support: mysql, mariadb, postgres, mssql
    // dialectOptions: {
    //   charset: 'utf8mb4',
    // },
    database: 'wx_shop',
    host: '127.0.0.1',
    port: '3306',
    username: 'you username',
    password: 'you password',
    timezone: '+08:00',
  };
```

#### **使用**
生命model，sequlize提供了很多数类型，这里不一一相叙，有兴趣的可以去看 `sequlize` [官网](https://github.com/demopark/sequelize-docs-Zh-CN/)，这是中文翻译。

model层
```
// users.js

'use strict'

module.exports = function (sequelize, DataTypes) {
  return sequelize.define('user', {
    uid: {
      type: DataTypes.INTEGER(11),
      allowNull: false, 
      primaryKey: true,
      autoIncrement: true
    },
    username: {
      type: DataTypes.STRING,
      allowNull: true, // 允许空值
    },
    password: {
      type: DataTypes.STRING,
      allowNull: true,
    }
  }, {
    tableName: 'user'
  })
}

```
查询
```
Modle.findaAll({
    // 查询条件语句
})
```
具体的增删查改文档里面写的很详细，使用具体看文档.

先写到这里，后面会继续更新！





