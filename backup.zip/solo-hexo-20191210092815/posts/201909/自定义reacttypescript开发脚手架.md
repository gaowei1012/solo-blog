title: 自定义react、typescript开发脚手架
date: '2019-09-04 11:52:16'
updated: '2019-10-22 12:57:43'
tags: [webpack, typescript]
permalink: /articles/2019/09/04/1567569136582.html
---
![](https://img.hacpai.com/bing/20180427.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

为什么会写这篇文章呢，主要想记录下自己遇到的问题，以供后续查找。

一、前期准备

  react全家桶，typescript、webpack

1.1 初始化工程
```
mkdir webpack-react-project && cd webpack-react-project && npm init -y
```

1.2 安装依赖
```
npm i -D react react-dom react-router-dom webpack webpack-cli typescript @type/react @type/react-dom @type/react-router-dom
```
暂时先安装这么多，后面需要用那个了再安装.

1.3 目录结构
```
// webpack-react-project

.
├── Dockerfile
├── README.md
├── config
│   ├── webpack.base.js
│   ├── webpack.dev.js
│   └── webpack.prod.js
├── package-lock.json
├── package.json
├── src
│   ├── App.ts
│   ├── assets
│   │   └── index.html
│   ├── components
│   │   └── header
│   │       ├── index.css
│   │       ├── index.css.map
│   │       ├── index.sass
│   │       └── index.tsx
│   ├── main.tsx
│   ├── router
│   ├── store
│   ├── styles
│   │   ├── global.css
│   │   ├── global.css.map
│   │   └── global.sass
│   └── views
│       └── Home.tsx
├── tsconfig.json
└── webpack.config.js
```
1.4 创建webpack配置文件
```
const path = require("path");
const HtmlWebPackPlugin = require("html-webpack-plugin");

module.exports = {
  mode: 'development',
  entry: {
    app: ["./src/App.ts"],
    vendor: ["react", "react-dom"]
  },
  output: {
    path: path.resolve(__dirname, "dist"),
    filename: "js/[name].bundle.js"
  },
  devtool: "source-map",
  resolve: {
    extensions: [".ts", ".tsx", ".js", ".jsx", ".json"]
  },
  module: {
    rules: [
      {
        test: /\.tsx?$/,
        loader: "awesome-typescript-loader"
      },
      {
        test: /\.s[ac]ss$/i,
        use: [
          'style-loader',
          'css-loader',
          {
            loader: 'sass-loader',
            options: {
              // Prefer `dart-sass`
              implementation: require('sass'),
              sassOptions: {
                fiber: false,
              },
            },
          },
        ],
      }
    ]
  },

  plugins: [
    new HtmlWebPackPlugin({
      template: path.resolve(__dirname, "../src/assets/index.html")
    })
  ]
};
```
这里的代码不懂可以去看[webpack]([https://www.webpackjs.com](https://www.webpackjs.com/))官网.

1.5 使用css预编译 `sass`
```
// webpack.config.js
// ...
{
        test: /\.s[ac]ss$/i,
        use: [
          'style-loader',
          'css-loader',
          {
            loader: 'sass-loader',
            options: {
              // Prefer `dart-sass`
              implementation: require('sass'),
              sassOptions: {
                fiber: false,
              },
            },
          },
        ],
      }
// ...
```


1.6 创建文件
 创建typescript，使用react+ts可谓是爽到家，体验一把吧
```
// Home page

import * as React from 'react';

export default class Home extends React.Component {
  public render(): JSX.Element {
    return (
      <>
        <p>this is home pages loading!!!\\\</p>
      </>
    )
  }
}

```

1.7 运行
```
npm run dev
```
如下图：
![wwww.png](https://img.hacpai.com/file/2019/09/wwww-7f1d43d1.png)
![youhua.png](https://img.hacpai.com/file/2019/09/youhua-623c6900.png)



至此，一个基础版的react全家桶+ts的脚手架工具搭建完毕！

![dash.png](https://img.hacpai.com/file/2019/10/dash-f69424a2.png)
![chart.png](https://img.hacpai.com/file/2019/10/chart-f537835c.png)

