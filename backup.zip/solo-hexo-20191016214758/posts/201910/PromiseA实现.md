title: Promise A+ 实现
date: '2019-10-16 18:27:54'
updated: '2019-10-16 21:38:31'
tags: [javascript]
permalink: /articles/2019/10/16/1571221674517.html
---
![](https://img.hacpai.com/bing/20180827.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)


`promise` 相信大家都用过，解决回调地狱，更优雅的写代码。

简易版：
```
'use strict'

/**
 * 思路：
 * promise所有两种状态 resolve, reject
 * pending是未完成状态
 * 1. 从 pending 到 resolve 成功
 * 2. 从 pedding 到 reject 失败
 * 
 */

function myPromise(constructor) {
  let self = this;
  self.stauts = 'pending'; // 未完成状态
  self.value = undefined
  self.resaon = undefined

  function resolve(value) {
    if (self.stauts === 'pending') {
      self.value = value
      self.stauts = 'resolved'// 成功
    }
  }

  function reject(resaon) {
    if (self.stauts === 'pending') {
      self.resaon = resaon
      self.resaon = 'rejected'// 失败
    }
  }
  try {
    constructor(resolve, reject)
  } catch(e) {
    reject(e)
  }
}

myPromise.prototype.then = function(onFullfiled, onRejected) {
  let self = this
  switch(self.stauts) {
    case 'resolved':
      onFullfiled(self.value)
      break
    case 'rejected':
      onRejected(self.resaon)
    break
    default:
      break
  }
}
```
测试:

```
// test
let promise = new myPromise(function(resolve, reject) {
  resolve(1)
})

promise.then(function(s) {
  console.log(s)
})
```

遵循Promise A+ [规范](https://www.ituring.com.cn/article/66566)：
```
// 完成中...
``
