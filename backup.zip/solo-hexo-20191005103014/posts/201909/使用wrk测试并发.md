title: 使用wrk测试并发
date: '2019-09-12 17:40:22'
updated: '2019-09-12 18:13:14'
tags: [工具]
permalink: /articles/2019/09/12/1568281222471.html
---
![](https://img.hacpai.com/bing/20190218.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

安装
```
git clone https://github.com/wg/wrk
```

```
make && sudo cp wrk /usr/local/bin // 编译并添加到系统目录
```
```
$ wrk --help
Usage: wrk <options> <url>
 Options:
 -c, --connections <N> Connections to keep open
 -d, --duration <T> Duration of test
 -t, --threads  <N> Number of threads to use
 -s, --script <S> Load Lua script file
 -H, --header <H> Add header to request
 --latency Print latency statistics
 --timeout  <T> Socket/request timeout
 -v, --version Print version details

 Numeric arguments may include a SI unit (1k, 1M, 1G)
 Time arguments may include a time unit (2s, 2m, 2h)
```
常用的参数为：

  

+ `-t`: 线程数（线程数不要太多，是核数的 2 到 4 倍即可，多了反而会因为线程切换过多造成效率降低）
+ `-c`: 并发数
+ `-d`: 测试的持续时间，默认为 10s
+ `-T`: 请求超时时间
+ `-H`: 指定请求的 HTTP Header，有些 API 需要传入一些 Header，可通过 Wrk 的 `-H` 参数来传入
+ `--latency`: 打印响应时间分布
+ `-s`: 指定 Lua 脚本，Lua 脚本可以实现更复杂的请求

Wrk分析结果
```bash
wrk -t4 -c10000 -d30s http://127.0.0.1:8080/v1/user
Running 30s test @ http://127.0.0.1:8080/v1/user
  4 threads and 10000 connections
  Thread Stats   Avg      Stdev     Max   +/- Stdev
    Latency   447.31ms  191.22ms   1.85s    79.84%
    Req/Sec   138.44    113.05     0.91k    81.00%
  8552 requests in 30.10s, 18.86MB read
  Socket errors: connect 9751, read 108, write 7, timeout 0
Requests/sec:    284.13
Transfer/sec:    641.81KB
```
注：由于我刚刚用我自己博客做实验导致博客崩掉，大家千万小心尝试😀
![zx.png](https://img.hacpai.com/file/2019/09/zx-237da41a.png)

