title: typescript
date: '2019-09-06 14:04:54'
updated: '2019-09-09 16:09:06'
tags: [typescript]
permalink: /articles/2019/09/06/1567749894265.html
---
![](https://img.hacpai.com/bing/20180904.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

一、基础
1.1、定义变量
```
// 使用let
let a = '123';
// 使用const
const b = '1221';
// 使用 readonly 只读
readonly a = 'hello';
```
1.2、接口
1.2-1、普通接口定义及使用
```
// 普通接口定义
interface UserInfo {
	user: string,
	name: string,
	readonly password: string, // 定义只读 
}
// 使用
class People implements UserInfo {
	name: string;	
	constructor(h: number, w: number);
}
```
1.2-2、定义静态接口
```
// static interface
interface ClockConstructor { 
	new (hour: number, minute: number); 
}

class Clock implements ClockConstructor { 
	currentTime: Date; 
	constructor(h: number, m: number) { } 
}

```
1.2-3、接口继承
```
interface Ones {
    age: number
}

interface Two extends Ones {
   name: string
}

let test = <Two> { }

// console 
test.age = 18;
test.name = '小明';
 
```
1.3、类
```
// 定义一个类
class Animal {
	move(distanceInMeters: number = 0) {
 		console.log(`Animal moved ${distanceInMeters}m.`); 
	}
 } 
// 继承
class Dog extends Animal {
	 bark() {
		 console.log('Woof! Woof!'); 
	}
 }
// 类的实例
 const dog = new Dog(); 
 dog.bark();  
 dog.move(10); 
 dog.bark();
```
借官网上一例子：
```
// 定义一个动物类
class Animal {
    name: string;
    constructor(theName: string) { this.name = theName; }
    move(distanceInMeters: number = 0) {
        console.log(`${this.name} moved ${distanceInMeters}m.`);
    }
}

// Snake 继承 动物类
class Snake extends Animal {
// super 继承父类的构造，在构造里访问this
    constructor(name: string) { super(name); }
    move(distanceInMeters = 5) {
        console.log("Slithering...");
        super.move(distanceInMeters);
    }
}

// Horse 继承 动物类
class Horse extends Animal {
// super 继承父类的构造，在构造里访问this
    constructor(name: string) { super(name); }
    move(distanceInMeters = 45) {
        console.log("Galloping...");
        super.move(distanceInMeters);
    }
}

// 类的实例方法
let sam = new Snake("Sammy the Python");
let tom: Animal = new Horse("Tommy the Palomino");

sam.move();
tom.move(34);
```
修饰符（ `public` && `private`）
```
class Animal {
// 私有修饰符
    private name: string;
// 公有修饰符
    public constructor(theName: string) { this.name = theName; }
// 私有修饰符、但`protected`成员在派生类中仍然可以访问
    protected move(distanceInMeters: number = 0) {
        console.log(`${this.name} moved ${distanceInMeters}m.`);
    }
}
```
portected 修饰符：
```
// 官网的例子
class Person {
    protected name: string;
    constructor(name: string) { this.name = name; }
}

class Employee extends Person {
    private department: string;

    constructor(name: string, department: string) {
        super(name)
        this.department = department;
    }

    public getElevatorPitch() {
        return `Hello, my name is ${this.name} and I work in ${this.department}.`;
    }
}

let howard = new Employee("Howard", "Sales");
console.log(howard.getElevatorPitch());
console.log(howard.name); // 错误
```
 readonly修饰符

```

class Octopus {
// 只读的字段（readonly）
    readonly name: string;
    readonly numberOfLegs: number = 8;
    constructor (theName: string) {
        this.name = theName;
    }
}

let dad = new Octopus("Man with the 8 strong legs");
dad.name = "Man with the 3-piece suit"; // 错误! name 是只读的.
```
静态修饰器
```
static state = { /* code */ };
```
抽象类
```
// 抽象类
abstract class AbstractClass { 
    /* code */
}
```
函数
```
// 类似于javascript中的函数定义
function add(x: number, y:number): any {
    return x + y;
}
```
**泛型** 
```
// 举一个简单的🌰
function (age: number): any {
    return age;
}
// 此时的函数接收一个任意参数，对于错的把控就小了很多bug，（不可控性）

```
基本使用
```
// T 👍 泛型
function Add<T>(num: T): T {
    console.log(num.length)// 报错，此时并不知道num是否为数组
    return num;
}

function loading<T> (arg: T[]): T[] {
    console.log(arg.length) // 此时 arg 为数组，并不会报错
    return arg
}
```
泛型的类型
```
function identity<T>(arg: T): T {
    return arg;
}

let myIdentity: <T>(arg: T) => T = identity;
```
泛型类型可以是下面这种：
```
function identity<U>(arg: U): U { 
    return arg
}

// 这个使用 `U` 表示
let myInject: <U>(arg: U) => U = identity

// 这个使用 `T` 表示
let myIdentity: <T>(arg: T) => T = identity;

```
* 注： 泛型函数的类型与非泛型函数的类型没什么不同，只是有一个类型参数在最前面，像函数声明一样：见上面代码示例！

```
function Interal<T>(arg: T): T { 
    return arg;
}

// 使用带有签名的对象

let interal: { <T>(arg: T): T } = Interal;
```
泛型接口：
```
// 泛型接口
interface GenericIndentityFn { 
    <T>(arg: T): T;
}

function interal<T>(arg: T): T { 
    return arg;
}

let myInteral: GenericIndentityFn = interal;
```
枚举
```
enum Demo {
	X = 1,
	Y,
	Z
}
// 输出 1, 2, 3
```
枚举 -- 严格模式
```
// 严格模式
const enum Demo {
	X = 1,
	y,
	Z
}
// 输出 1，2，3
```
类型推论
```
let s = 3; // 推论出 x 为数字
let y = 'heloo'; // 推论出 y 为字符串
```
交叉类型
```
// 交叉类型
// 何所谓交叉类型呢，可以加但理解，就是去两者的交集部分

function extend<T, U>(s: T, y: U): T & U { 
    let result = <T & U>{}
    for (let id in s) { 
        (<any>result)[id] = (<any>s)[id]
    }
    for (let id in y) { 
        if (!result.hasOwnProperty(id)) { 
            (<any>result)[id] = (<any>y)[id]
        }
    }
    return result
}
class Person { 
    constructor(
        public name: string
    ) { }
}

interface Loggable { 
    log(): void;
}

class ConsoleLogger implements Loggable { 
    log() { 
        // todo
    }
}
```
联合类型
所谓的联合类型就是两者之和（即包括两者在内的所有类型）

类型检查
```
// typeof检查数据类型
function isString(x: any): x is string {
	return typeof x === 'string'
}
```
```
// 使用 interface
interface Padder {
    getPaddingString(): string
}

class SpaceRepeatingPadder implements Padder {
    constructor(private numSpaces: number) { }
    getPaddingString() {
        return Array(this.numSpaces + 1).join(" ");
    }
}

class StringPadder implements Padder {
    constructor(private value: string) { }
    getPaddingString() {
        return this.value;
    }
}

function getRandomPadder() {
    return Math.random() < 0.5 ?
        new SpaceRepeatingPadder(4) :
        new StringPadder("  ");
}

// 类型为SpaceRepeatingPadder | StringPadder
let padder: Padder = getRandomPadder();

if (padder instanceof SpaceRepeatingPadder) {
    padder; // 类型细化为'SpaceRepeatingPadder'
}
if (padder instanceof StringPadder) {
    padder; // 类型细化为'StringPadder'
}
```


