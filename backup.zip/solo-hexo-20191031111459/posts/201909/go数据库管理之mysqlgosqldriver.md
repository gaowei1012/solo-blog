title: go数据库管理之mysql（go-sql-driver）
date: '2019-09-14 14:48:10'
updated: '2019-09-14 15:12:35'
tags: [go]
permalink: /articles/2019/09/14/1568443690704.html
---
![](https://img.hacpai.com/bing/20190711.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

  go中没有提供自己的数据库驱动，但是提供了 `database/sql` 数据库接口，我们可以针对自己的业务封装。

  为了简单，我们采用 `go-sql-driver` 这个驱动，他是用纯 `go` 去写的，现在就来看看怎么使用吧！

```
package sql

import (
	"fmt"
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
)

func main() {
	// 连接数据库
	db, err := sql.Open("mysql", "root:youpassword@/database")
	if err != nil {
		//panic(err.Error())
		fmt.Printf("err", err)
	}
	// 等待关闭连接
	defer db.Close()

	// 插入数据
	stmt, err := db.Prepare("INSERT INTO userinfo VALUES( ?, ? )")
	if err != nil {
		//panic(err.Error())
		fmt.Printf("err", err)
	}
	defer stmt.Close()

	// 查询数据
	rows, err := db.Prepare("SELECT * from userinfo")
	if err != nil {
		//panic(err.Error())
		fmt.Printf("err", err)
	}

	columns, err := rows.Columns()
	if err != nil {
		//panic(err.Error())
		fmt.Printf("err", err)
	}

	values := make([]sql.RawBytes, len(Columns))
	
	scanArgs := make([]interface{}, len(values))
	for i= range values {
		scanArgs[i] = &values[i]
	}

	for rows.Nest() {
		err = rows.Scan(scanArgs...)
		if err != nil {
			fmt.Printf("err", err)
		}
	}

	var value string
	for i, col := range values {
		if col == nil {
			value == "NULL"
		} else {
			value = string(col)
		}
		fmt.Println(colummns[i] , " : " , value)
	}

	if err = rows.Err(); err != nil {
		//panic(err.Error()) // proper error handling instead of panic in your app
		fmt.Printf("err", err.Error())
	}
}
```
