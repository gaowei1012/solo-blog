title: dcoker搭建web服务器
date: '2019-09-03 18:16:59'
updated: '2019-09-04 12:04:26'
tags: [docker]
permalink: /articles/2019/09/03/1567505819698.html
---
![](https://img.hacpai.com/bing/20190831.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

#### 1.背景

---

电脑环境杂乱，为了更好的提高开发效率，而不影响其他环境，使用docker容器，基本安装请参考[官网](https://docs.docker.com/docker-for-mac/install/ "官网")。

系统: Mac ox 10.13.4
docker: v18.09.2

---

### 2.搭建web服务器

拉去到本地

```shell
 docker run -p 80 --name web -i -t centos /bin/bash 
```

该命令指定在80端口创建一个web服务器使用的容器的centos,并且直接进入到容器中，这就很简单创建了一个web服务器了。  
![](https://gaomingwei.xyz/wp-content/uploads/2019/07/WX20190720-064759.png)

* 安装 `nginx`  
    使用下面命令拉去nginx:

```shell
rpm -ivh http://nginx.org/packages/centos/7/noarch/RPMS/nginx-release-centos-7-0.el7.ngx.noarch.rpm
```

安装：

```shell
yum install -y nginx
```

看到这里，nginx安装完毕！


```
//启动
systemctl start nginx.service
```

常用nginx命令，请查看[官网文档](http://nginx.org/en/docs/ "官网文档")

安装node  
    使用nvm，安装node管理
```
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.34.0/install.sh | bash
``` 

```
//加入系统环境，并载入
source ~/.bashrc
```

```
//查看所有的node版本
nvm list-remote
```

```
//安装node
nvm install v10.16.0
```

安装 pm2

```
npm install -g pm2
```

*至此一个docker服务器搭建完成*

### 3. docker 常用命令

查看本地容器

```shell
docker ps -a
```

开启容器

```shell
docker start <id> // 容器id
```

进入容器

```shell
docker attach <id> // 容器id
```

停止容器

```shell
docker stop <id> // 容器 id
```

搜索线上容器

```shell
docker search <attr>
```
