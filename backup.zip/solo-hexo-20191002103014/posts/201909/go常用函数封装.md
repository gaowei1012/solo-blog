title: go 常用函数封装
date: '2019-09-29 15:11:54'
updated: '2019-09-29 15:39:31'
tags: [go]
permalink: /articles/2019/09/29/1569741114295.html
---
![](https://img.hacpai.com/bing/20180716.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

go 实现字符串翻转

```
// 示例
func reverser(s []int)  {
	for i, j := 0, len(s)-1 ; i < j; i, j = i+ 1, j-1{
		s[i], s[j] = s[j], s[i]
	}
}

arr := [...]int{0,1,2,3,4,5,6,7,8,9}
reverser(a)// {9,8,7,6,5,4,3,2,1,0}
```

比较两个元素串是否相等

```
// 比较两个元素是否相等
func equal(x, y []string) bool {
	if len(x) != len(y) {
		return false
	}

	for i := range x {
		if x[i] != y[i] {
			return false
		}
	}

	return true
}

// 示例

	b := []string{"2"}
	c := []string{"2"}

	equal(b, c)

	fmt.Println(equal(b, c)) // true
```
内置append方法使用

```
func appendInt(x []int, y int) []int {
	var z []int
	zlen := len(x) + 1
	if zlen <= cap(x) {
		z = x[:zlen]
	} else {
		zcap := zlen
		if zcap < 2*len(x) {
			zcap = 2 * len(x)
		}
		z = make([]int, zlen, zcap)
		copy(z, x)
	}
	z[len(x)] = y
	return z
}
```
