title: 使用typescript重构react项目
date: '2019-09-05 15:12:47'
updated: '2019-09-05 16:35:24'
tags: [typescript, react]
permalink: /articles/2019/09/05/1567667567816.html
---
首先来看下typescript写react的一个小demo
```
import React, {Component} from 'react

const initState = {value: 0}
type State = Readonly<typeof initState>

class Index extneds Component<object, state> {
	
	public handleClick = () => this.setState(AddFunction)

	render():JSX.Element {
		const value = this.state 
		return(
			<div>
				<button onClick={this.handleClick}>Add</button>
				<p>{value}</p>
			</div>
		)
	}
}

// 纯函数，便于测试
const AddFunction = (prevState: State)  => ({
	value: prevState.value + 1
})
```

上面的demo实现了一个有状态组件,
 现在有一个问题，props现在传递的都是比传递参数，怎么可以实现可选，并在并在我们使用组件时有代码提示；

首先解决可选参数问题
```
type Props = {
	onClick(e: MouseEvent<HTMLElement>): void, // 必选参数
	children?: string, // 可选参数
	color?: string 
}
// 由上面的demo可知，我不在多讲
```
但是这样，我们使用组件时并不会有代码提示，进而，我们需要封装一个高级组件来处理。

```
// withDefaultProps.tsx

import { ComponentType } from "react";

export const withDefaultProps = <
  // props 
  P extends object,
  // defaultprops
  DP extends Partial<P> = Partial<P>
  >(defaultProps: DP, Cmp: ComponentType<P>) => {

  // 提取必要属性
  type RequiredProps = Omit<P, keyof DP>;
   // 重新创建我们的属性定义，通过一个相交类型，将所有的原始属性标记成可选的，必选的属性标记成可选的
  type Props = Partial<DP> & Required<RequiredProps>;

  Cmp.defaultProps = defaultProps;

  return (Cmp as ComponentType<any> as ComponentType<Props>);
}

```
进而，我们可以在组件中这样使用
```
// demo.tsx
import React, {MouseEvent, SFC} from 'react'
import { withDefaultProps } from '../../hook/withDefaultProps'

const defaultProps = {
  color: 'red'
}

type DefaultProps = typeof defaultProps
type Props = { 
  onClick(e: MouseEvent<HTMLElement>): void,
  children?: string,
  color?: string
} & DefaultProps

const Button: SFC<Props> = ({onClick: handleClick, children}) => (
  <button onClick={handleClick ? handleClick : undefined}>{children}</button>
);

const ButtonWithDefaultProps = withDefaultProps(defaultProps, Button) 

export default ButtonWithDefaultProps;
```
ok,这样就搞定！
![2323.png](https://img.hacpai.com/file/2019/09/2323-53da4228.png)

下面展示一例子
```
import React, { Component, MouseEvent } from 'react';
import { isFunction } from '../utils';

// 初始化state
const initialState = {
  show: false,
};

type State = Readonly<typeof initialState>;

// 定义props类型全部都为可选的 `Partial` 参数                      
type Props = Partial<{
  children: RenderCallback;
  render: RenderCallback;
}>;

type RenderCallback = (args: ToggleableComponentProps) => JSX.Element;

//这里我们使用了TypeScript的__查找类型（lookup types）__，所以我们又不需要重复地去定义类型了：

// `show: State['show']`我们利用已有的state类型定义了`show`属性
// `toggle: Toggleable['toggle']`我们利用了TS从类实现推断类类型来定义`toggle`属性。很好用而且非常强大。

type ToggleableComponentProps = {
  show: State['show'];
  toggle: Toggleable['toggle'];
};

export class Toggleable extends Component<Props, State> {
  readonly state: State = initialState;

  render() {
    const { render, children } = this.props;
    const renderProps = {
      show: this.state.show,
      toggle: this.toggle,
    };

    if (render) {
      return render(renderProps);
    }

    return isFunction(children) ? children(renderProps) : null;
  }

  private toggle = (event: MouseEvent<HTMLElement>) =>
    this.setState(updateShowState);
}

const updateShowState = (prevState: State) => ({ show: !prevState.show });

```

