title: JavaScript常用函数实现
date: '2019-10-17 09:35:53'
updated: '2019-10-17 09:35:53'
tags: [javascript]
permalink: /articles/2019/10/17/1571276153614.html
---
实现一个new操作符号
```
/*
   思路：
	创建一个对象，改变该对象的this指向
*/
function _new(fn, ...args) {
    const obj = Object.create(fn.propotype)
    const rest = fn.apply(obj, args)
    return rest instanceof Object ? rest : obj
}
```

实现一个instanceof

```
/*
    思路：
	取两个要比较的对象左右两边的value
	比较左边的value是否等于右边的__propo__
*/
function new_instance_of(letValue, rightValue) {
    let rigthProp = rightValue.prototype
    leftValue = leftValue.__propo__
    while(true) {
        if (leftValue === null) {
            return false
        }
	if (leftValue === rigthProp) {
	    return true
	}

	leftValue = leftValue.__propo__
    }
}
```

