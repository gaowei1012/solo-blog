title: javascript 事件(event) loop
date: '2019-09-03 19:41:54'
updated: '2019-09-03 19:42:38'
tags: [javascript]
permalink: /articles/2019/09/03/1567510913841.html
---
![](https://img.hacpai.com/bing/20181215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

JavaScript是一个单线程语言，为了实现主线程不阻塞 Event Loop应运而生.  
浏览器和node中的event loop并不一样，浏览器是基于HTML5找那个定义的，尔nodejs是基于libv库实现的。

**浏览器中Event** loop

* 所有同步任务都在主线程上执行，形成一个执行栈
* 主线程之外，还存在另外一个红任务
    * 任务栈分为macro-task(宏任务)和micro-task(微任务)
    * macro-task: setTimeout, setInterval ... (定时器)
    * micro-task: process.nextTick, 原生Promise 等

**执行流程如下图:**

[![event-loop](https://user-images.githubusercontent.com/25763661/51449801-ae532680-1d68-11e9-98df-8944b310b792.png)](https://user-images.githubusercontent.com/25763661/51449801-ae532680-1d68-11e9-98df-8944b310b792.png)

**执行流程：**  
1.浏览器中，先执行当前栈，执行完主执行线程中的任务。  
2.取出Microtask微任务队列中任务执行直到清空。  
3.取出Macrotask宏任务中 一个 任务执行。  
4.检查Microtask微任务中有没有任务，如果有任务执行直到清空。  
5.重复3和4。
```
  console.log(1);
  console.log(2);
  setTimeout(function() {
    console.log('setTimeout1');
    Promise.resolve().then(function() {
       console.log('Promise');
    }) 
  })
  setTimeout(function() {
    console.log('setTimeout2')
  })
// 1, 2, setTimeout1, promise, setTimeout2
```

**node中的事件环:**

* 在libuv内部有这样有个事件环机制， 在node启动时会初始事件环
* node中的event loop 分为6个阶段，不同于浏览器的是，这里每一个阶段都会有一个事件队列，node会在当前阶段中全部任务执行完，清空NextTick Queue，清空Micritask Queue，再执行下一阶段。
* 在nodejs里，process 对象表示nodejs应用程序，可以获得应用程序的用户。  
    process.nextTick()方法将callback添加到next tick 队列 并且nextTick优先于promise、Microtask。

1. timers： 执行setTimeout() 和 setInterval() 中到期的callback  
    2.I/O callback: 上一轮循环中有少数的I/O callback 会被延迟到这一轮  
    3.idle promose: 对列的移动，仅内部使用
2. poll: 最为重要的阶段，执行I/O callback，在适当的条件下会阻塞在这个阶段  
    5.check: 执行setTimmediate的callback  
    6.close callbacks: 执行 close事件的callback

[![event-loop2](https://user-images.githubusercontent.com/25763661/51450710-ba40e780-1d6c-11e9-9616-007b6bb1510e.png)](https://user-images.githubusercontent.com/25763661/51450710-ba40e780-1d6c-11e9-9616-007b6bb1510e.png)

**在终端执行下面这段代码:**
```
setTimeout(function(){
  console.log('timeout')  
})
setImmediate(function(){
  console.log('immediate')
})
```
在每次执行完后，他们的执行结果先后顺序不一样，用为在node需要启动时，执行过程中setTimeout可能到时间了也可能没到时间，所以这个先后顺序取决于node的执行时间。

**i/o操作阶段完成后，会走check阶段，所以steimmediate会有先走：**
```
let fs = require('fs');
fs.redFile('./1.txt', function() {
  console.log('2');
  setTiemout(function() {
    console.lg('setTimeout')
  })
  setImmediate(funciton(){
     console.log('setTimmediate')          
  })
})
```
**nextTick应用场景**
```
function Fn(){
  this.arrs;
  process.nextTick(()=>{ //根据nextTick的特性，可以先赋值，再在下一个队列中使用
    this.arrs();
  })
}
Fn.prototype.then=function(){
  this.arrs=function(){console.log(1)}
}
let fn=new Fn();
fn.then();
```
//注意：nextTick千万不要写递归，不然会造成死循环。可以放一些比setTimeout优先执行的任务
