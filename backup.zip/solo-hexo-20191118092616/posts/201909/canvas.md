title: canvas
date: '2019-09-04 06:50:59'
updated: '2019-09-04 06:50:59'
tags: [javascript, Canvas]
permalink: /articles/2019/09/04/1567551059666.html
---
一、绘制一个时钟
```
// index.html
<canvas id="canvas" width="400" height="400"></canvas>

// index.js
// canvas 绘制动态时钟
(function() {
  const drawing = document.querySelector("#canvas");

  // 浏览器是否支持canvas
  if (drawing.getContext) {
    const context = drawing.getContext("2d");
    let width = context.canvas.width;
    let height = context.canvas.height;
    let r = width / 2; // 半径
    let rem = width / 400;

    //绘制时钟背景
    function drawBackgroud() {
      context.save();
      context.translate(r, r);
      context.beginPath();
      context.lineWidth = 10 * rem;
      context.arc(0, 0, r - context.lineWidth / 2, 0, 2 * Math.PI, false);

      context.stroke();

      let hourNumbers = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 1, 2];
      hourNumbers.map(function(number, i) {
        let rad = 2 * Math.PI / 12 * i;
        let x = Math.cos(rad) * (r - 30 * rem);
        let y = Math.sin(rad) * (r - 30 * rem);
        context.textAlign = "center";
        context.textBaseline = "middle";
        context.font = 18 * rem + "px Arial";
        context.fillText(number, x, y);
      });

      for (let i = 0; i < 60; i++) {
        let rad = 2 * Math.PI / 60 * i;
        let x = Math.cos(rad) * (r - 18 * rem);
        let y = Math.sin(rad) * (r - 18 * rem);
        context.beginPath();
        if (i % 5 === 0) {
          context.fillStyle = "#000";
        } else {
          context.fillStyle = "#ccc";
        }
        context.arc(x, y, 2 * rem, 2 * Math.PI, false);
        context.fill();
      }
    }

    // 绘制时钟
    function drawHour(hour, minute) {
      context.save();
      context.beginPath();
      let rad = 2 * Math.PI / 12 * hour;
      let mrad = 2 * Math.PI / 12 / 60 * minute;
      context.rotate(rad + mrad); // 旋转
      context.lineWidth = 6 * rem;
      context.moveTo(0, 10 * rem);
      context.lineTo(0, -r / 2); // 旋转方向
      context.lineCap = "round"; //end
      context.stroke();
      context.restore();
    }

    // 绘制分钟
    function drawMinute(minute) {
      context.save();
      context.beginPath();
      let rad = 2 * Math.PI / 60 * minute;
      context.rotate(rad);
      context.lineWidth = 3 * rem;
      context.moveTo(0, 10 * rem);
      context.lineTo(0, -r / 2 - 10);
      context.lineCap = "round";
      context.stroke();
      context.restore();
    }

    // 绘制second
    function drawSecond(second) {
      context.save();
      context.beginPath();
      let rad = 2 * Math.PI / 60 * second;
      context.rotate(rad);
      context.lineWidth = 3;
      context.moveTo(-2 * rem, 20 * rem);
      context.lineTo(2 * rem, 20 * rem);
      context.lineTo(1, -r + 18 * rem);
      context.lineTo(1, -r + 18 * rem);
      context.fillStyle = "#e4393c";
      context.fill();
      context.restore();
    }

    function drawDot() {
      context.beginPath();
      context.fillStyle = "#fff";
      context.arc(0, 0, 3 * rem, 2 * Math.PI, false);
      context.fill();
    }

    function draw() {
      context.clearRect(0, 0, width, height);
      let now = new Date();
      let hour = now.getHours();
      let minute = now.getMinutes();
      let second = now.getSeconds();
      drawBackgroud();
      drawHour(hour, minute);
      drawMinute(minute);
      drawSecond(second);
      drawDot();
      context.restore();
    }

    setInterval(draw, 1000);
  } else {
    console.log('您的浏览器不支持canvas，-<<<<<->>>>>-!!!');
  }
})(0);
```

二、绘制动态粒子背景
```
// index.html
// 省略css样式
<canvas id="canvas"></canvas>

// index.js

function drawLine() {
  // 使用requestAdminationFrame代替setTimeout
  window.requestAnimationFrame = window.requestAnimationFrame 
    || window.mozRequestAnimationFrame 
    || window.webkitRequestAnimationFrame 
    || window.msRequestAnimationFrame;

  const drawing = document.querySelector('#canvas');

  if (drawing.getContext) {

    // 获取上下文
    let ctx = drawing.getContext('2d');

    // 获取宽、高
    var width = drawing.width = canvas.offsetWidth;
    var height = drawing.height = canvas.offsetHeight;
    let circles = [];

    let current_cricle = new currentCircle(0, 0);

    function init(num) {
      for(let i = 0; i < num; i++ ) {
        circles.push(new circle(Math.random() * width, Math.random() * height));
      }
      draw()
    }

    function draw() {
      ctx.clearRect(0, 0, width, height);
      for(let i = 0; i < circles.length; i++) {
        circles[i].move(width, height);
        circles[i].drawCircle(ctx);
        for(let j = i + 1; j < circles.length; j++) {
          circles[j].drawLine(ctx, circles[j])
        }
      }

      if (current_cricle.x) {
        current_cricle.drawCircle(ctx);
        for(let k = 0; k < circles.length; k++) {
          current_cricle.drawLine(ctx, circles[k]);
        }
      }

      requestAnimationFrame(draw)
    }

    window.onmousemove = function(e) {
      e = e || window.event;
      current_cricle.x = e.clientX;
      current_cricle.y = e.clientY;
    }

    window.onmouseout = function() {
      current_cricle.x = null;
      current_cricle.y = null;
    }

    // 绘制圆 x, y 坐标
    function circle(x, y) {
      this.x = x;
      this.y = y;
      this.r = Math.random() * 10;
      this._mx = 1 - (Math.random() * 2);
      this._my = 1 - (Math.random() * 2);

      // canvas画圆
      this.drawCircle = drawCircle;
      function drawCircle(ctx) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.r, 0, 360);
        ctx.fillStyle = 'rgba(201,204,204,0.3)';
        ctx.fill();
      }

      this.move = move;
      function move(width, height) {
        this._mx = (this.x < width && this.x > 0) ? this._mx : (-this._mx);
        this._my = (this.x < height && this.y > 0) ? this._my : (-this._my);
        this.x += this._mx / 2;
        this.y += this._my / 2;
      }

      // canvas 画线
      this.drawLine = drawLine;
      function drawLine(ctx, _circle) {
        var dx = this.x - _circle.x;
        var dy = this.y - _circle.y;
        var d = Math.sqrt(dx * dx + dy * dy);
        if (d < 150) {
          ctx.beginPath();
          ctx.moveTo(this.x, this.y);//起点
          ctx.lineTo(_circle.x, _circle.y);//终点
          ctx.strokeStyle = 'rgba(204, 204, 204, 0.3)';
          ctx.stroke();
        }
      }
    }

    function currentCircle(x, y) {
      circle.call(this, x, y);

      this.drawCircle = drawCircle;
      function drawCircle(ctx) {
        ctx.beginPath();
        ctx.arc(this.x, this.y, 8, 0, 360);
        ctx.fillStyle = 'rgba(255, 77, 54, 0.6)';
        ctx.fill()
      }
    }

  } else {
    console.log('您的浏览器不支持canvas');
  }

  init(160);

}

drawLine();
```
