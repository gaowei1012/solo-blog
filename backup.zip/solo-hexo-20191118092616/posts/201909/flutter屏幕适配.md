title: flutter屏幕适配
date: '2019-09-03 18:00:15'
updated: '2019-09-03 19:24:11'
tags: [flutter, 移动端适配]
permalink: /articles/2019/09/03/1567504815365.html
---
![](https://img.hacpai.com/bing/20171104.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

**之前可以用一个第三方插件来适配，但是呢，用于种种原因，现在自己封装一个插件，自由使用。**

```
import 'package:flutter/widgets.dart';
/// UI适配
class SizeConfig {

  static MediaQueryData _mediaQueryData;
  static double screentWidth;
  static double screenyHeight;
  static double blockSizeHorizontal;
  static double blockSizeVertical;

  static double _safeAreaHorizontal;
  static double _safeAreaVertical;
  static double safeBlockHorizontal;
  static double safeBlockVertical;

  void init(BuildContext context) {
    _mediaQueryData = MediaQuery.of(context);
    screentWidth = _mediaQueryData.size.width;
    screenyHeight = _mediaQueryData.size.height;
    blockSizeHorizontal = screentWidth / 100;
    blockSizeVertical = screenyHeight / 100;

    _safeAreaHorizontal = _mediaQueryData.padding.left + _mediaQueryData.padding.right;
    _safeAreaVertical = _mediaQueryData.padding.top + _mediaQueryData.padding.bottom;
    safeBlockHorizontal = (screentWidth - _safeAreaHorizontal) / 100;
    safeBlockVertical = (screenyHeight - _safeAreaVertical) / 100;
  }
}
```

**二、在对应页面初始化**

```
/// 初始化插件
    SizeConfig().init(context);
```

**三、使用**

```
height: SizeConfig.blockSizeHorizontal * 20;
```
