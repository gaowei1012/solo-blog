title: go中form表单注册使用
date: '2019-09-09 16:41:48'
updated: '2019-09-09 18:02:46'
tags: [go]
permalink: /articles/2019/09/09/1568018508253.html
---
![](https://img.hacpai.com/bing/20180424.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

```
package main

// 处理表单提交数据
import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"strings"
)
// 首页
func sayHelloName(w http.ResponseWriter, r *http.Request)  {
	r.ParseForm() // 解析url传递参数，对于POST则解析主体{body}
	fmt.Println(r.Form)
	fmt.Println(r.Response) //
	fmt.Println(r.URL.Path)// url
	fmt.Println(r.Form["url-long"])
	for k, v := range r.Form {
		fmt.Println("key", k)
		fmt.Println("val", strings.Join(v, ""))
	}
	fmt.Fprintf(w, "很高兴，你又看到我了")
}

// 登录方法
func login(w http.ResponseWriter, r *http.Request)  {
	r.ParseForm()
	fmt.Println("method", r.Method)// 请求方法
	if r.Method == "GET" {
		t, _ := template.ParseFiles("login.gtpl")
		log.Println(t.Execute(w, nil))
	} else {
		fmt.Println("username", r.Form["username"])
		fmt.Println("password", r.Form["password"])
	}
}

// 运行方法
func main()  {
	http.HandleFunc("/", sayHelloName)
	http.HandleFunc("/login", login)
	err := http.ListenAndServe(":9090", nil)
	if err != nil {
		log.Fatal("ListenAndServe", err)
	}
}

```
如下图：
// 首页
![say.png](https://img.hacpai.com/file/2019/09/say-becdc721.png)
// 登录成功
![ohinm.png](https://img.hacpai.com/file/2019/09/ohinm-79b562e3.png)



