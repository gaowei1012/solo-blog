title: go运行中出现的问题
date: '2019-09-11 11:30:33'
updated: '2019-09-11 11:30:33'
tags: [go]
permalink: /articles/2019/09/11/1568172633651.html
---
![](https://img.hacpai.com/bing/20171128.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

运行go报错  `  cannot find package "golang.org/x/sys/unix" in any of: ` 被墙了，这样解决：

在go的src在创建 `goland.org/x` 目录
挂代理，这里比较快
然后 `git clone https://github.com/golang/sys.git`
解决！





