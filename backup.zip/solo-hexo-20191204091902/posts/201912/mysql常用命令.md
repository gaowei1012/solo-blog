title: mysql 常用命令
date: '2019-12-01 10:22:28'
updated: '2019-12-01 10:50:38'
tags: [mysql]
permalink: /articles/2019/12/01/1575166947552.html
---
![](https://img.hacpai.com/bing/20180228.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```sql
#/bash/sh

# 显示数据库:
show databases;
>>> mysql ....

# 显示表:
show tables;
>>> posts 

# 查询当前表所对应的columns(列):
use mysql;
>>> success
# 查询表列
show columns from posts; 
>>>
+----------+--------------+------+-----+---------+----------------+
| Field    | Type         | Null | Key | Default | Extra          |
+----------+--------------+------+-----+---------+----------------+
| id       | int(11)      | NO   | PRI | NULL    | auto_increment |
| username | varchar(100) | NO   |     | NULL    |                |
| password | varchar(100) | NO   |     | NULL    |                |
| phone    | int(11)      | NO   |     | NULL    |                |
+----------+--------------+------+-----+---------+----------------+
4 rows in set (0.00 sec)


# 显示授权用户
show grants;
>>>
+---------------------------------------------------------------------+
| Grants for root@localhost                                           |
+---------------------------------------------------------------------+
| GRANT ALL PRIVILEGES ON *.* TO 'root'@'localhost' WITH GRANT OPTION |
| GRANT PROXY ON ''@'' TO 'root'@'localhost' WITH GRANT OPTION        |
+---------------------------------------------------------------------+
2 rows in set (0.00 sec)

# 显示系统信息
show status;

# 检索多个列
select username, password, phone from users;
>>>
# 表中没有数据
Empty set (0.00 sec)

# 过滤检查中重复字段
select distinct vend_id from products;

# 限制返回结果（多少）
# 从5开始检查5个
# limit 是从0开始的，类似于`js`中的数组
select username from users limit 5, 5;
Empty set (0.00 sec)

# 使用order by 进行查找排序
# 默认查找，并不会对数据进行排序，在某些特定的场景下我们需要对数据进行排序
# 例如，升序，降序
# 按照价格去排序
select price from products order by price;

# 同样的我们可以对一个商品集合进行多个排序
select product_id, product_name, product_num from products order by product_id, product_name; 

# 排序指定方向
# 升序排列

select product_id, product_name, product_price from products order by product_price desc;

# 降序排列
select product_id, product_name, product_price from products product_name desc, product_price;

```
