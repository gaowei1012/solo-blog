title: docker 使用之（mysql）
date: '2019-12-07 22:43:57'
updated: '2019-12-07 22:50:31'
tags: [docker]
permalink: /articles/2019/12/07/1575729837348.html
---
![](https://img.hacpai.com/bing/20191006.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

系统：centos 7
	docker 
 	mysql

首先要在centos 中安装 docker 具体安装方法这里不详述，具体可以上网找，

```bash
# 启动 docker
systemctl start docker

# 拉取镜像
docker pull mysql

# 创建mysql
docker run -p 13306:3306 --name my-mysql -v $PWD/conf:/etc/mysql -v $PWD/data:/var/lib/mysql -e MYSQL_ROOT_PASSWORD=123456 -d mysql:5.7.26

# 查看运行容器
docker ps 

# 进入mysql容器
# mysql 是 你的mysql docker 名称
docker exec -it mysql bash


```
![WX20191207224153.png](https://img.hacpai.com/file/2019/12/WX20191207224153-0f242a2f.png)

![WX20191207224254.png](https://img.hacpai.com/file/2019/12/WX20191207224254-586b794e.png)



