title: docker 使用之（nginx）
date: '2019-12-07 22:49:56'
updated: '2019-12-07 22:50:16'
tags: [dcoker]
permalink: /articles/2019/12/07/1575730196288.html
---
![](https://img.hacpai.com/bing/20181109.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

使用 docker 来管理我们的环境，是一个不错的解决方案，下面介绍安装配置 doker nginx 

```bash

# 安装 nginx

docker pull nginx

# 创建 nginx 环境

docker run --name my-nginx -p 8088:80 -d nginx

# 进入容器

docker exec -it my-nginx bash

```
![WX20191207224838.png](https://img.hacpai.com/file/2019/12/WX20191207224838-1515dd7d.png)

![WX20191207224924.png](https://img.hacpai.com/file/2019/12/WX20191207224924-318f8953.png)


