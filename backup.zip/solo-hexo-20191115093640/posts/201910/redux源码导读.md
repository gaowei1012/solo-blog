title: redux源码导读
date: '2019-10-21 11:59:59'
updated: '2019-10-22 00:07:47'
tags: [redux]
permalink: /articles/2019/10/21/1571630399154.html
---
`react`只负责`UI`层，那么`redux`就应运而生，redux是基于 [Flux](https://github.com/facebook/flux) 想深入了解的可以去看看官网的介绍，这里主要对 `redux`进行梳理分析。

`Flux` 架构：
![fluxdiagramwhitebackground.png](https://img.hacpai.com/file/2019/10/fluxdiagramwhitebackground-d7d562dd.png)

应用所有数据会存在store中，通过getState获取分发数据， action通过dispatch提交数据，reducers做出相应， view视图层发生改变。

`applyMiddleware:`
```
function applyMiddleware(...middleware) {
    return (createStore) => (reducer, preloadedState, enhancer) => {
	var store = createStore(reducer, preloadedState, enhancer)
    	var dispatch = store.dispatch
    	var chain = []

	var middlewareAPI = {
      		getState: store.getState,
      		dispatch: (action) => dispatch(action)
    	};
    	chain = middlewares.map(middleware => middleware(middlewareAPI));
    	dispatch = compose(...chain)(store.dispatch);

    	return {...store, dispatch}
    }
}
```
让我们用一句话两件讲清楚react配合redux使用的， 首先创建store，创建redcers ， reducers是纯函数， actions进行数据处理（异步&同步），映射到组件 mapStateToProps, 从组件提交 更新 mapDispatchToProps。



