title: go 搭建简易web服务器
date: '2019-09-08 17:52:12'
updated: '2019-09-08 17:53:28'
tags: [go]
permalink: /articles/2019/09/08/1567936332789.html
---
![](https://img.hacpai.com/bing/20181030.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

关于基础知识，大家可以去看golang中文网，案例很详细，很简单

下面直接进入正题
搭建一个简易web服务器

```
package main

import (
	"fmt"
	"log"
	"net/http"
	"strings"
)

func sayHelloName(w http.ResponseWriter, r * http.Request)  {
	r.ParseForm() // 解析参数
	fmt.Println(r.Form)
	fmt.Println("path", r.URL.Path)// path 路径
	fmt.Println("scheme", r.URL.Scheme)// url
	fmt.Println(r.Form["url-log"])
	for k, v := range r.Form  {
		fmt.Println("key", k)
		fmt.Println("val", strings.Join(v, ""))
	}
// 输出值
	fmt.Fprintf(w, "hello atx")
}

// 运行
func main()  {
	http.HandleFunc("/", sayHelloName)
	err := http.ListenAndServe(":9090", nil)
	if err != nil {
		log.Fatal("LiseterServer", "err")
	}
}

```

如下图所示
![go.png](https://img.hacpai.com/file/2019/09/go-e3accff5.png)

