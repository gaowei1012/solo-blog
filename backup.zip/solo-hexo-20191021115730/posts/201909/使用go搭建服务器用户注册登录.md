title: 使用go搭建服务器，（用户注册登录）
date: '2019-09-09 13:39:23'
updated: '2019-09-09 13:39:23'
tags: [go]
permalink: /articles/2019/09/09/1568007563657.html
---
![](https://img.hacpai.com/bing/20190728.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
package main

import (
	"net/http"
	"log"
	"encoding/json"
)
// 用户
type Account struct {
	Name string
	Password string
}

// 结果
type Result struct {
	Ok bool
}

func main()  {
	accounts := make([]*Account, 0, 6)

	http.HandleFunc("/register", func(w http.ResponseWriter, r *http.Request) {

		// 获取用户名和密码
		name := r.FormValue("Name")
		password := r.FormValue("Password")

		if HasAccountByName(accounts, name) {
			ReturnResult(false, w)
		} else {
			// 没有给该用户
			accounts = append(accounts, &Account{
				Name:name,
				Password:password,
			})
			ReturnResult(true, w)
		}
	})

	// http login
	http.HandleFunc("/login", func(w http.ResponseWriter, r *http.Request) {

		// 获取用户名密码
		name := r.FormValue("Name")
		password := r.FormValue("Password")

		if IsAccountPwdMath(accounts, name, password) {
			ReturnResult(true, w)
		} else {
			ReturnResult(false, w)
		}
	})

	log.Println("server start ...")
	log.Fatal(http.ListenAndServe(":8080", nil))
}

// 返回给客户端结果
func ReturnResult(result bool, w http.ResponseWriter)  {
	re := &Result{Ok:result}

	// json 格式化
	j, _ := json.Marshal(re)

	// 发送给客户端
	w.Write([]byte(j))
}

// 是否是当前该用户
func HasAccountByName(as []*Account, name string) bool {
	for _, v := range as {
		if v.Name == name {
			return true
		}
	}
	return false
}

// 判断是否注册
func IsAccountPwdMath(as []*Account, name string, password string) bool {
	for _, v := range as {
		if v.Name == name && v.Password == password {
			return true
		}
	}
	return false
}

```

如下图：
![as.png](https://img.hacpai.com/file/2019/09/as-b7f65242.png)

